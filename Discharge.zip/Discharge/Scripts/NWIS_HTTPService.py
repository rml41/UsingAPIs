#NWIS_HTTPService.py
#
#Description: Retrieves real time discharge data for a user supplied
#             USGS Gage Site. The latest gage data is returned as 
#             an ArcPy message (for reporting in ArcGIS)
#
# John.Fay@duke.edu
# Fall 2019

# import the modules
import sys, urllib, arcpy

# Get the input HUC8 Number
GageID = arcpy.GetParameterAsText(0)

# construct the url
URL = 'http://waterdata.usgs.gov/nwis/uv?' + \
	  'cb_00060=on&' + \
	  'cb_00065=on&' + \
	  'format=rdb&' + \
	  'period=1&' + \
	  'site_no='+ str(GageID)

# pull the contents of the URL into the data variable 
data = urllib.request.urlopen(URL)
# convert the data page into a line list
lines = data.readlines()
#Get the header items line and parse into items
headers = lines[27].decode('utf-8').split('\t')
#Get the index corresponding to discharge ()
#discharge_idx = headers.find(')


# get the last line (most recent data)
lastline = lines[-1]
# parse the last line into a list
linedata = lastline.decode("utf-8").split("\t")
# check to see that a site was selected
if linedata[0][0:2] == "No":
    arcpy.AddError("Gage " + GageID + " was not found")
    sys.exit(1)
# put the list objects into recognizeable variables
site = linedata[1]
date = linedata[2]
discharge = linedata[6]
gage_ht = linedata[4]
# send the results back as parameters
arcpy.SetParameterAsText(1, date)
arcpy.SetParameterAsText(2, discharge)
arcpy.SetParameterAsText(3, gage_ht)
# Also send back a message (as warning so it stands out)
arcpy.AddWarning("Site #" + site + " has a discharge of " + \
              discharge + " cfs and a gage ht of " + gage_ht + \
              " feet at " + date)

