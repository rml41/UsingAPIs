#NWIS_HTTPService.py
#
#Description: Retrieves real time discharge data for a user supplied
#             USGS Gage Site. The latest gage data is returned as 
#             an ArcPy message (for reporting in ArcGIS)
#
# John.Fay@duke.edu
# Fall 2019

# import the modules
import sys, os, arcpy
import pandas as pd
from matplotlib import pyplot as plt

# Turn interactive plotting off
import matplotlib
matplotlib.use('Agg')

# Get the input HUC8 Number and output plot name as inputs
GageID = arcpy.GetParameterAsText(0)
out_PNG = arcpy.GetParameterAsText(1)

# construct the url
arcpy.AddMessage("Querying NWIS server")
URL = 'http://waterdata.usgs.gov/nwis/uv?' + \
	  'cb_00060=on&' + \
	  'cb_00065=on&' + \
	  'format=rdb&' + \
	  'period=10&' + \
	  'site_no='+ str(GageID)

#Create list of non data row numbers
skipRows = list(range(27))
skipRows.append(28)

#Read data into a dataframe
arcpy.AddMessage("Creating dataframe")
df = pd.read_csv(URL,skiprows=skipRows,sep='\t',parse_dates=[2])

#Check that the data contains discharge
if not '00060' in df.columns[4]:
    #If not, exit
    arcpy.AddError("Discharge not found in data for {}".format(GageID))
    sys.exit(-1)
    
 #Set the date as the index
df.set_index('datetime',inplace=True)

#Construct the plot
fig = plt.figure()
plt.plot(df.iloc[:,3])
plt.xticks(rotation=90)
plt.ylabel("Discharge (cfs)")
plt.title("Gage site: {}".format(GageID))

#Save the plot
if os.path.exists(out_PNG): os.remove(out_PNG)
plt.savefig(out_PNG)

#Show the plot
os.startfile(out_PNG,'open')

#Get the values of the most recent reading
date = df.iloc[-1,2]
discharge = df.iloc[-1,3]
gage_ht = df.iloc[-1,5]

#Report the most recent discharge and gage ht & return as parameters
arcpy.SetParameterAsText(2, date)
arcpy.SetParameterAsText(3, discharge)
arcpy.SetParameterAsText(4, gage_ht)

# Also send back a message (as warning so it stands out)
arcpy.AddWarning("Site # {} has a discharge of {}cfs and a gage ht of {}".
                 format(date,discharge,gage_ht))
